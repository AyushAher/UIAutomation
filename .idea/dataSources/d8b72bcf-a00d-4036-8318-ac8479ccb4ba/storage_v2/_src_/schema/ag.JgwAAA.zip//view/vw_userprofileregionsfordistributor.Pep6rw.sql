create view vw_userprofileregionsfordistributor as
select `d`.`distname` AS `Level1Name`,
       ''             AS `Level2Name`,
       ''             AS `Level2Level1Name`,
       `d`.`id`       AS `Level1id`,
       `d`.`id`       AS `Level2id`,
       `pr`.`id`      AS `profileregionId`,
       `up`.`id`      AS `userprofileid`
from ((`ag`.`userprofiles` `up` left join `ag`.`profileregion` `pr` on (((`up`.`id` = `pr`.`userprofileid`) and
                                                                         (`up`.`profilefor` =
                                                                          (select `ag`.`listtypeitems`.`id`
                                                                           from `ag`.`listtypeitems`
                                                                           where (`ag`.`listtypeitems`.`code` = 'DIST'))))))
         left join `ag`.`distributor` `d` on ((`pr`.`regionid` = `d`.`id`)))
union
select `d`.`distname`     AS `Level1Name`,
       `dr`.`region`      AS `Level2Name`,
       `dr`.`distregname` AS `Level2Level1Name`,
       `d`.`id`           AS `Level1id`,
       `dr`.`id`          AS `Level2id`,
       `pr`.`id`          AS `profileregionId`,
       `up`.`id`          AS `userprofileid`
from (((`ag`.`userprofiles` `up` left join `ag`.`profileregion` `pr` on (((`up`.`id` = `pr`.`userprofileid`) and
                                                                          (`up`.`profilefor` =
                                                                           (select `ag`.`listtypeitems`.`id`
                                                                            from `ag`.`listtypeitems`
                                                                            where (`ag`.`listtypeitems`.`code` = 'REG')))))) left join `ag`.`distregions` `dr` on ((`pr`.`regionid` = `dr`.`id`)))
         left join `ag`.`distributor` `d` on ((`dr`.`distid` = `d`.`id`)));

