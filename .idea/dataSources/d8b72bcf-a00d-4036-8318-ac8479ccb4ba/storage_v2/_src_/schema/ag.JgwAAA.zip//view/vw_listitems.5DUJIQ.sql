create view vw_listitems as
select `l`.`code`      AS `listcode`,
       `l`.`id`        AS `listtypeid`,
       `l`.`listname`  AS `listname`,
       `li`.`id`       AS `listtypeitemid`,
       `li`.`code`     AS `itemcode`,
       `li`.`itemname` AS `itemname`
from (`ag`.`listtype` `l`
         join `ag`.`listtypeitems` `li` on ((`l`.`id` = `li`.`listtypeid`)));

