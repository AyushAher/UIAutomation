create view vw_distributornregions as
select `d`.`distname` AS `Level1Name`,
       ''             AS `Level2Name`,
       ''             AS `Level2Level1Name`,
       `d`.`id`       AS `Level1id`,
       `d`.`id`       AS `Level2id`,
       `c`.`id`       AS `ContactId`
from ((`ag`.`contact` `c` left join `ag`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`)))
         left join `ag`.`distributor` `d` on (((`cm`.`parentid` = `d`.`id`) and (`cm`.`mappedfor` =
                                                                                 (select `ag`.`listtypeitems`.`id`
                                                                                  from `ag`.`listtypeitems`
                                                                                  where (`ag`.`listtypeitems`.`code` = 'DIST'))))))
union
select `d`.`distname`     AS `Level1Name`,
       `dr`.`region`      AS `Level2Name`,
       `dr`.`distregname` AS `Level2Level1Name`,
       `d`.`id`           AS `Level1id`,
       `dr`.`id`          AS `Level2id`,
       `c`.`id`           AS `ContactId`
from (((`ag`.`contact` `c` left join `ag`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `ag`.`distributor` `d` on ((
        (`cm`.`parentid` = `d`.`id`) and (`cm`.`mappedfor` = (select `ag`.`listtypeitems`.`id`
                                                              from `ag`.`listtypeitems`
                                                              where (`ag`.`listtypeitems`.`code` = 'DIST'))))))
         left join `ag`.`distregions` `dr` on ((`dr`.`distid` = `d`.`id`)));

