create view vw_insconfigspareparts as
select `sp`.`id`                AS `id`,
       `sp`.`isactive`          AS `isactive`,
       `sp`.`configtypeid`      AS `configtypeid`,
       `licg`.`itemname`        AS `configtypename`,
       `sp`.`partno`            AS `partno`,
       `sp`.`itemdesc`          AS `itemdesc`,
       `sp`.`qty`               AS `qty`,
       `sp`.`parttype`          AS `parttype`,
       `sp`.`desccatalogue`     AS `desccatalogue`,
       `sp`.`hscode`            AS `hscode`,
       `sp`.`countryid`         AS `countryid`,
       `c`.`name`               AS `countryname`,
       `sp`.`price`             AS `price`,
       `sp`.`currencyid`        AS `currencyid`,
       `cr`.`name`              AS `currencyname`,
       `lipt`.`itemname`        AS `parttypename`,
       `sp`.`image`             AS `image`,
       `sp`.`isobselete`        AS `isobselete`,
       `sp`.`replacepartnoid`   AS `replacepartnoid`,
       `sp`.`configvalueid`     AS `configvalueid`,
       `cv`.`configvalue`       AS `configvaluename`,
       `ic`.`instrumentid`      AS `instrumentid`,
       ifnull(`ic`.`insqty`, 0) AS `insqty`
from ((((((`ag`.`spareparts` `sp` left join `ag`.`instrumentconfig` `ic` on ((
        (`sp`.`configtypeid` = `ic`.`configtypeid`) and (`sp`.`configvalueid` = `ic`.`configvalueid`) and
        (`sp`.`id` = `ic`.`sparepartid`)))) left join `ag`.`country` `c` on ((`sp`.`countryid` = `c`.`id`))) left join `ag`.`currency` `cr` on ((`sp`.`currencyid` = `cr`.`id`))) left join `ag`.`listtypeitems` `licg` on ((`sp`.`configtypeid` = `licg`.`id`))) left join `ag`.`configtypevalues` `cv` on ((`sp`.`configvalueid` = `cv`.`id`)))
         left join `ag`.`listtypeitems` `lipt` on ((`sp`.`parttype` = `lipt`.`id`)));

