create view vw_sites as
select `cu`.`custname`   AS `Level1Name`,
       `s`.`regname`     AS `Level2Name`,
       `s`.`custregname` AS `Level2Level1Name`,
       `cu`.`id`         AS `Level1id`,
       `s`.`id`          AS `Level2id`,
       `c`.`id`          AS `ContactId`
from (((`ag`.`contact` `c` left join `ag`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `ag`.`customer` `cu` on ((
        (`cm`.`parentid` = `cu`.`id`) and (`cm`.`mappedfor` = (select `ag`.`listtypeitems`.`id`
                                                               from `ag`.`listtypeitems`
                                                               where (`ag`.`listtypeitems`.`code` = 'CUST'))))))
         left join `ag`.`site` `s` on ((`cu`.`id` = `s`.`custid`)))
union
select `cu`.`custname`   AS `Level1Name`,
       `s`.`regname`     AS `Level2Name`,
       `s`.`custregname` AS `Level2Level1Name`,
       `cu`.`id`         AS `Level1id`,
       `s`.`id`          AS `Level2id`,
       `c`.`id`          AS `ContactId`
from (((`ag`.`contact` `c` left join `ag`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `ag`.`site` `s` on ((
        (`cm`.`parentid` = `s`.`id`) and (`cm`.`mappedfor` = (select `ag`.`listtypeitems`.`id`
                                                              from `ag`.`listtypeitems`
                                                              where (`ag`.`listtypeitems`.`code` = 'SITE'))))))
         left join `ag`.`customer` `cu` on ((`s`.`custid` = `cu`.`id`)));

