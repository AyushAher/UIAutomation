create view vw_userprofileregionsforsite as
select `cu`.`custname`   AS `Level1Name`,
       `s`.`regname`     AS `Level2Name`,
       `s`.`custregname` AS `Level2Level1Name`,
       `cu`.`id`         AS `Level1id`,
       `s`.`id`          AS `Level2id`,
       `pr`.`id`         AS `profileregionId`,
       `up`.`id`         AS `userprofileid`
from (((`ag`.`userprofiles` `up` left join `ag`.`profileregion` `pr` on (((`up`.`id` = `pr`.`userprofileid`) and
                                                                          (`up`.`profilefor` =
                                                                           (select `ag`.`listtypeitems`.`id`
                                                                            from `ag`.`listtypeitems`
                                                                            where (`ag`.`listtypeitems`.`code` = 'SITE')))))) left join `ag`.`site` `s` on ((`pr`.`regionid` = `s`.`id`)))
         left join `ag`.`customer` `cu` on ((`s`.`custid` = `cu`.`id`)));

